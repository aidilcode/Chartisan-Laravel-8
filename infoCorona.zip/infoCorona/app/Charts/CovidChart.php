<?php

declare(strict_types=1);

namespace App\Charts;

use Chartisan\PHP\Chartisan;
use ConsoleTVs\Charts\BaseChart;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class CovidChart extends BaseChart
{
    /**
     * Handles the HTTP request for the given chart.
     * It must always return an instance of Chartisan
     * and never a string or an array.
     */
    public function handler(Request $request): Chartisan
    {
        $req = collect(Http::get('https://api.kawalcorona.com/indonesia/provinsi')->json());
        $labels = $req->flatten(1)->pluck('Provinsi');
        $data = $req->flatten(1)->pluck('Kasus_Posi');
        $data2 = $req->flatten(1)->pluck('Kasus_Meni');
        $data3 = $req->flatten(1)->pluck('Kasus_Semb');

        return Chartisan::build()
            ->labels($labels->toArray())
            ->dataset('Kasus Positif', $data->toArray())
            ->dataset('Kasus Meninggal', $data2->toArray())
            ->dataset('Kasus Sembuh', $data3->toArray());
    }
}
